# Notes-app

- Create, save, update, delete notes instantly.
- Search notes quickly.
- Sort notes according to your choice.
